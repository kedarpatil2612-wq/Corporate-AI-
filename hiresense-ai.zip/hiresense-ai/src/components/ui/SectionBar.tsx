// ── SectionBar ────────────────────────────────────────────────────────────────
// Animated horizontal bar for a single section score.

import React, { useEffect, useState } from 'react';
import { scoreColor } from '@/utils/ui';

interface SectionBarProps {
  label: string;
  value: number;
  /** CSS transition-delay in seconds */
  delay?: number;
}

export const SectionBar: React.FC<SectionBarProps> = ({ label, value, delay = 0 }) => {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), delay * 1000 + 150);
    return () => clearTimeout(t);
  }, [delay]);

  const color = scoreColor(value);

  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 500, color, fontFamily: "'JetBrains Mono', monospace" }}>
          {value}
        </span>
      </div>
      {/* Track */}
      <div
        style={{
          height: 5,
          background: 'var(--bg-muted)',
          borderRadius: 99,
          overflow: 'hidden',
        }}
      >
        {/* Fill */}
        <div
          style={{
            height: '100%',
            background: color,
            borderRadius: 99,
            width: animated ? `${value}%` : '0%',
            transition: `width 1s ${delay * 0.12}s cubic-bezier(0.4, 0, 0.2, 1)`,
          }}
        />
      </div>
    </div>
  );
};
