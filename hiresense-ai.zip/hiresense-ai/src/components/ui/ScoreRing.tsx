// ── ScoreRing ─────────────────────────────────────────────────────────────────
// Animated SVG radial progress ring for the resume score.

import React, { useEffect, useState } from 'react';
import { scoreColor } from '@/utils/ui';

interface ScoreRingProps {
  score: number;
  size?: number;
}

export const ScoreRing: React.FC<ScoreRingProps> = ({ score, size = 180 }) => {
  const [animated, setAnimated] = useState(false);

  // Trigger animation after mount
  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(t);
  }, []);

  const strokeWidth = 10;
  const radius      = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset      = animated
    ? circumference - (score / 100) * circumference
    : circumference;

  const color = scoreColor(score);

  const grade =
    score >= 93 ? 'A+' : score >= 85 ? 'A'  : score >= 77 ? 'B+' :
    score >= 70 ? 'B'  : score >= 62 ? 'C+' : score >= 55 ? 'C'  :
    score >= 45 ? 'D'  : 'F';

  return (
    <div
      style={{ position: 'relative', width: size, height: size, margin: '0 auto' }}
      aria-label={`Resume score: ${score} out of 100`}
    >
      {/* Track */}
      <svg
        width={size}
        height={size}
        style={{ transform: 'rotate(-90deg)', display: 'block' }}
        aria-hidden="true"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--bg-muted)"
          strokeWidth={strokeWidth}
        />
        {/* Progress arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1.6s cubic-bezier(0.4, 0, 0.2, 1)' }}
        />
      </svg>

      {/* Centre text */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 2,
        }}
      >
        <span
          style={{
            fontSize: size * 0.24,
            fontWeight: 600,
            fontFamily: "'Syne', sans-serif",
            color,
            lineHeight: 1,
            transition: 'color 0.4s',
          }}
          className="anim-count-up"
        >
          {score}
        </span>
        <span style={{ fontSize: 11, color: 'var(--text-dim)', letterSpacing: 1 }}>/100</span>
        <span
          style={{
            marginTop: 4,
            fontSize: 12,
            fontWeight: 600,
            color,
            background: 'var(--bg-muted)',
            padding: '1px 10px',
            borderRadius: 99,
            fontFamily: "'Syne', sans-serif",
            letterSpacing: '0.05em',
          }}
        >
          {grade}
        </span>
      </div>
    </div>
  );
};
