// ── DropZone ──────────────────────────────────────────────────────────────────
// Drag-and-drop file upload area with hover state.

import React, { useRef, useState, useCallback } from 'react';
import { Upload, FileText, X } from 'lucide-react';
import type { UploadedFile } from '@/types';
import { formatFileSize } from '@/utils/ui';

interface DropZoneProps {
  uploadedFile: UploadedFile | null;
  isReading: boolean;
  error: string;
  onFile: (file: File | null) => void;
  onClear: () => void;
}

export const DropZone: React.FC<DropZoneProps> = ({
  uploadedFile,
  isReading,
  error,
  onFile,
  onClear,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else setDragActive(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);
      const file = e.dataTransfer.files?.[0];
      if (file) onFile(file);
    },
    [onFile],
  );

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      onFile(e.target.files?.[0] ?? null);
      // Reset so the same file can be re-selected
      e.target.value = '';
    },
    [onFile],
  );

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept=".pdf,.txt,application/pdf,text/plain"
        style={{ display: 'none' }}
        onChange={handleChange}
      />

      {uploadedFile ? (
        // ── File selected state ──────────────────────────────────────────────
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '14px 16px',
            background: 'var(--brand-dim)',
            border: '1px solid rgba(245,158,11,0.3)',
            borderRadius: 12,
          }}
        >
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 8,
              background: 'rgba(245,158,11,0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <FileText size={18} color="var(--brand)" />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p
              style={{
                fontSize: 13,
                fontWeight: 500,
                color: 'var(--text)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {uploadedFile.name}
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>
              {formatFileSize(uploadedFile.size)} ·{' '}
              {uploadedFile.encoding === 'base64-pdf' ? 'PDF' : 'Plain text'}
            </p>
          </div>
          <button
            onClick={onClear}
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              padding: 4,
              borderRadius: 4,
              display: 'flex',
            }}
            aria-label="Remove file"
          >
            <X size={14} />
          </button>
        </div>
      ) : (
        // ── Empty drop zone ──────────────────────────────────────────────────
        <div
          className={`drop-zone ${dragActive ? 'drag-active' : ''}`}
          style={{ padding: '40px 24px', textAlign: 'center' }}
          onClick={() => inputRef.current?.click()}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          role="button"
          tabIndex={0}
          aria-label="Click or drag to upload resume"
          onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
        >
          {isReading ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  border: '2px solid var(--border)',
                  borderTopColor: 'var(--brand)',
                  borderRadius: '50%',
                  animation: 'spin 0.7s linear infinite',
                }}
              />
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Reading file…</span>
            </div>
          ) : (
            <>
              <div
                style={{
                  width: 48,
                  height: 48,
                  margin: '0 auto 12px',
                  borderRadius: 12,
                  background: dragActive ? 'var(--brand-dim)' : 'var(--bg-muted)',
                  border: `1px solid ${dragActive ? 'rgba(245,158,11,0.4)' : 'var(--border)'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s',
                }}
              >
                <Upload size={20} color={dragActive ? 'var(--brand)' : 'var(--text-muted)'} />
              </div>
              <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--text)', marginBottom: 4 }}>
                Drop your resume here
              </p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                or{' '}
                <span style={{ color: 'var(--brand)', textDecoration: 'underline', cursor: 'pointer' }}>
                  click to browse
                </span>
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 8 }}>
                PDF or TXT · max 5 MB
              </p>
            </>
          )}
        </div>
      )}

      {/* Error message */}
      {error && (
        <div
          style={{
            marginTop: 8,
            padding: '8px 12px',
            background: 'rgba(239,68,68,0.08)',
            border: '1px solid rgba(239,68,68,0.25)',
            borderRadius: 8,
            fontSize: 12,
            color: '#f87171',
          }}
        >
          ⚠ {error}
        </div>
      )}
    </div>
  );
};
