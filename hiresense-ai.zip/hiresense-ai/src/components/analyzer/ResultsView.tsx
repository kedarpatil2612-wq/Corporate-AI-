// ── ResultsView ───────────────────────────────────────────────────────────────
// Dashboard showing score, section breakdown, strengths/weaknesses, suggestions,
// and ATS keyword analysis.

import React from 'react';
import { RefreshCw, CheckCircle2, AlertTriangle, Lightbulb, Tag, Printer } from 'lucide-react';
import { ScoreRing } from '@/components/ui/ScoreRing';
import { SectionBar } from '@/components/ui/SectionBar';
import type { AnalysisResult } from '@/types';
import { scoreColor } from '@/utils/ui';

interface ResultsViewProps {
  result: AnalysisResult;
  onReset: () => void;
}

// ── Sub-components ────────────────────────────────────────────────────────────

interface ListCardProps {
  title: string;
  icon: React.ReactNode;
  items: string[];
  accent: string;
  delay?: number;
}

const ListCard: React.FC<ListCardProps> = ({ title, icon, items, accent, delay = 0 }) => (
  <div
    className={`card anim-slide-up delay-${delay}`}
    style={{ padding: '18px 16px', height: '100%' }}
  >
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
      <span style={{ color: accent }}>{icon}</span>
      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', fontFamily: "'Syne', sans-serif" }}>
        {title}
      </span>
    </div>
    <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {items.map((item, i) => (
        <li key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <span style={{ color: accent, marginTop: 2, flexShrink: 0, fontSize: 10 }}>●</span>
          <span style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.55 }}>{item}</span>
        </li>
      ))}
    </ul>
  </div>
);

// ── Main component ────────────────────────────────────────────────────────────

export const ResultsView: React.FC<ResultsViewProps> = ({ result, onReset }) => {
  const {
    score,
    summary,
    sections,
    strengths,
    weaknesses,
    suggestions,
    keywords_found = [],
    keywords_missing = [],
  } = result;

  const color = scoreColor(score);

  const sectionLabels: Record<keyof typeof sections, string> = {
    skills:      'Skills & Technologies',
    experience:  'Work Experience',
    education:   'Education',
    formatting:  'Formatting & Clarity',
    impact:      'Measurable Impact',
  };

  return (
    <div
      style={{
        maxWidth: 860,
        margin: '0 auto',
        padding: '32px 16px 64px',
      }}
    >
      {/* ── Header ── */}
      <div
        className="anim-slide-up"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 28,
          flexWrap: 'wrap',
          gap: 12,
        }}
      >
        <div>
          <h1
            style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: 22,
              fontWeight: 700,
              color: 'var(--text)',
              letterSpacing: '-0.01em',
              marginBottom: 2,
            }}
          >
            Resume Analysis Report
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Powered by Claude claude-sonnet-4-20250514
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" onClick={() => window.print()} title="Print / Save as PDF">
            <Printer size={13} style={{ marginRight: 6, verticalAlign: 'middle' }} />
            Print
          </button>
          <button className="btn-ghost" onClick={onReset}>
            <RefreshCw size={13} style={{ marginRight: 6, verticalAlign: 'middle' }} />
            New Analysis
          </button>
        </div>
      </div>

      {/* ── Score + Section Breakdown ── */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: 16,
          marginBottom: 16,
        }}
      >
        {/* Score card */}
        <div
          className="card anim-slide-up delay-1"
          style={{
            padding: '24px 20px',
            textAlign: 'center',
            borderColor: `${color}30`,
          }}
        >
          <ScoreRing score={score} size={180} />
          {summary && (
            <p
              style={{
                marginTop: 16,
                fontSize: 13,
                color: 'var(--text-muted)',
                lineHeight: 1.6,
                textAlign: 'left',
                borderLeft: `3px solid ${color}`,
                paddingLeft: 12,
              }}
            >
              {summary}
            </p>
          )}
        </div>

        {/* Section breakdown */}
        <div
          className="card anim-slide-up delay-2"
          style={{ padding: '20px 18px' }}
        >
          <h3
            style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: 13,
              fontWeight: 600,
              color: 'var(--text)',
              marginBottom: 16,
            }}
          >
            Section Breakdown
          </h3>
          {(Object.entries(sectionLabels) as Array<[keyof typeof sections, string]>).map(
            ([key, label], i) => (
              <SectionBar
                key={key}
                label={label}
                value={sections[key] ?? 0}
                delay={i * 0.15}
              />
            ),
          )}
        </div>
      </div>

      {/* ── Strengths + Weaknesses ── */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: 16,
          marginBottom: 16,
        }}
      >
        <ListCard
          title="Strengths"
          icon={<CheckCircle2 size={15} />}
          items={strengths}
          accent="var(--success)"
          delay={3}
        />
        <ListCard
          title="Weaknesses"
          icon={<AlertTriangle size={15} />}
          items={weaknesses}
          accent="var(--danger)"
          delay={4}
        />
      </div>

      {/* ── Suggestions ── */}
      <div
        className="card anim-slide-up delay-5"
        style={{ padding: '18px 18px', marginBottom: 16 }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <Lightbulb size={15} color="var(--brand)" />
          <h3
            style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: 13,
              fontWeight: 600,
              color: 'var(--text)',
            }}
          >
            Suggestions for Improvement
          </h3>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {suggestions.map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <span
                style={{
                  minWidth: 22,
                  height: 22,
                  borderRadius: '50%',
                  background: 'var(--brand)',
                  color: '#1a0800',
                  fontSize: 11,
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  marginTop: 1,
                }}
              >
                {i + 1}
              </span>
              <span style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6 }}>{s}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Keywords ── */}
      {(keywords_found.length > 0 || keywords_missing.length > 0) && (
        <div
          className="card anim-slide-up delay-6"
          style={{ padding: '18px 18px' }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <Tag size={14} color="var(--info)" />
            <h3
              style={{
                fontFamily: "'Syne', sans-serif",
                fontSize: 13,
                fontWeight: 600,
                color: 'var(--text)',
              }}
            >
              ATS Keyword Analysis
            </h3>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {keywords_found.length > 0 && (
              <div>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>
                  ✓ Found in your resume:
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {keywords_found.map((k) => (
                    <span key={k} className="kw-chip found">{k}</span>
                  ))}
                </div>
              </div>
            )}

            {keywords_missing.length > 0 && (
              <div>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>
                  ↗ Consider adding:
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {keywords_missing.map((k) => (
                    <span key={k} className="kw-chip missing">{k}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
