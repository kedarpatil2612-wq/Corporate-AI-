// ── AnalyzingView ─────────────────────────────────────────────────────────────
// Full-screen animated loading state shown while Claude analyses the resume.

import React, { useEffect, useState } from 'react';

const STEPS = [
  'Parsing resume structure…',
  'Identifying skills & technologies…',
  'Evaluating experience depth…',
  'Checking ATS keyword density…',
  'Scoring impact metrics…',
  'Generating personalised feedback…',
  'Finalising your report…',
];

export const AnalyzingView: React.FC = () => {
  const [stepIndex, setStepIndex] = useState(0);
  const [progress, setProgress]   = useState(0);

  useEffect(() => {
    const stepTimer = setInterval(() => {
      setStepIndex((i) => (i + 1) % STEPS.length);
    }, 1100);

    const progressTimer = setInterval(() => {
      setProgress((p) => Math.min(p + 1.5, 95));
    }, 80);

    return () => {
      clearInterval(stepTimer);
      clearInterval(progressTimer);
    };
  }, []);

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 24px',
        textAlign: 'center',
      }}
    >
      {/* Orbital spinner */}
      <div
        style={{
          position: 'relative',
          width: 96,
          height: 96,
          marginBottom: 32,
        }}
      >
        {/* Outer ring */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            border: '2px solid var(--border)',
            borderRadius: '50%',
          }}
        />
        {/* Spinning arc */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            border: '2px solid transparent',
            borderTopColor: 'var(--brand)',
            borderRightColor: 'rgba(245,158,11,0.3)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
          }}
        />
        {/* Inner ring reverse */}
        <div
          style={{
            position: 'absolute',
            inset: 12,
            border: '1.5px solid transparent',
            borderTopColor: 'var(--brand)',
            borderRadius: '50%',
            animation: 'spin 1.5s linear infinite reverse',
            opacity: 0.5,
          }}
        />
        {/* Centre dot */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div
            style={{
              width: 12,
              height: 12,
              borderRadius: '50%',
              background: 'var(--brand)',
              animation: 'pulse-glow 2s ease-in-out infinite',
            }}
          />
        </div>
      </div>

      {/* Heading */}
      <h2
        style={{
          fontFamily: "'Syne', sans-serif",
          fontSize: 22,
          fontWeight: 600,
          color: 'var(--text)',
          marginBottom: 8,
        }}
      >
        Analyzing your resume
      </h2>

      {/* Rotating step message */}
      <p
        key={stepIndex}
        style={{
          fontSize: 14,
          color: 'var(--text-muted)',
          marginBottom: 32,
          minHeight: 20,
          animation: 'slide-up 0.3s ease both',
        }}
      >
        {STEPS[stepIndex]}
      </p>

      {/* Progress bar */}
      <div
        style={{
          width: 280,
          height: 4,
          background: 'var(--bg-muted)',
          borderRadius: 99,
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            height: '100%',
            background: 'var(--brand)',
            borderRadius: 99,
            width: `${progress}%`,
            transition: 'width 0.1s linear',
          }}
        />
      </div>
      <p
        style={{
          marginTop: 8,
          fontSize: 11,
          color: 'var(--text-dim)',
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        {Math.round(progress)}%
      </p>

      {/* Step dots */}
      <div style={{ display: 'flex', gap: 5, marginTop: 24 }}>
        {STEPS.map((_, i) => (
          <div
            key={i}
            style={{
              width: i === stepIndex ? 22 : 6,
              height: 4,
              borderRadius: 99,
              background: i === stepIndex ? 'var(--brand)' : 'var(--border)',
              transition: 'all 0.3s ease',
            }}
          />
        ))}
      </div>
    </div>
  );
};
