// ── UploadView ────────────────────────────────────────────────────────────────
// First screen: file upload + paste text tabs, sample resume picker, analyse button.

import React, { useState } from 'react';
import { Sparkles, ChevronDown } from 'lucide-react';
import { DropZone } from '@/components/ui/DropZone';
import { useFileReader } from '@/hooks/useFileReader';
import { analyzeResume, ruleBasedAnalysis } from '@/utils/analyzeResume';
import { SAMPLE_RESUMES, type SampleResumeKey } from '@/utils/sampleResumes';
import type { AnalysisResult, InputTab } from '@/types';

interface UploadViewProps {
  onResult: (result: AnalysisResult) => void;
  /** Called immediately when analysis starts; receives a display label */
  onAnalyzing: (label: string) => void;
}

export const UploadView: React.FC<UploadViewProps> = ({ onResult, onAnalyzing }) => {
  const [tab, setTab]           = useState<InputTab>('upload');
  const [pastedText, setPasted] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [apiError, setApiError] = useState('');
  const [showSamples, setShowSamples] = useState(false);

  const { uploadedFile, error: fileError, isReading, handleFile, clearFile } = useFileReader();

  const canAnalyze = tab === 'upload'
    ? !!uploadedFile
    : pastedText.trim().length > 30;

  const handleAnalyze = async () => {
    setApiError('');
    if (!canAnalyze) return;

    setIsAnalyzing(true);
    // Derive a human-readable label for the history entry
    const label =
      tab === 'upload' && uploadedFile
        ? uploadedFile.name.replace(/\.[^.]+$/, '')
        : 'Pasted Resume';
    onAnalyzing(label);

    try {
      const result = await analyzeResume(
        tab === 'upload' ? uploadedFile : null,
        tab === 'paste'  ? pastedText   : '',
      );
      onResult(result);
    } catch (err) {
      // Fallback: use rule-based scoring on whatever text we have
      const fallbackText = tab === 'paste' ? pastedText : (uploadedFile?.content ?? '');
      if (fallbackText && uploadedFile?.encoding !== 'base64-pdf') {
        onResult(ruleBasedAnalysis(fallbackText));
      } else {
        setApiError(
          err instanceof Error
            ? err.message
            : 'Analysis failed. Please check your connection and try again.',
        );
        setIsAnalyzing(false);
      }
    }
  };

  const loadSample = (key: SampleResumeKey) => {
    setTab('paste');
    setPasted(SAMPLE_RESUMES[key].text);
    setShowSamples(false);
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 16px',
      }}
    >
      {/* ── Hero ── */}
      <div className="anim-slide-up" style={{ textAlign: 'center', marginBottom: 40, maxWidth: 480 }}>
        {/* Logo mark */}
        <div
          style={{
            width: 56,
            height: 56,
            background: 'var(--brand)',
            borderRadius: 14,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 20px',
            boxShadow: '0 0 0 8px rgba(245,158,11,0.08)',
          }}
        >
          <Sparkles size={26} color="#1a0800" />
        </div>

        <h1
          style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: 'clamp(28px, 6vw, 42px)',
            fontWeight: 700,
            color: 'var(--text)',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: 12,
          }}
        >
          HireSense <span style={{ color: 'var(--brand)' }}>AI</span>
        </h1>

        <p style={{ fontSize: 15, color: 'var(--text-muted)', lineHeight: 1.6 }}>
          Upload your resume and get an instant AI-powered score, personalised
          strengths & weaknesses, and actionable suggestions.
        </p>

        {/* Feature pills */}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap', marginTop: 16 }}>
          {['Resume Score 0–100', 'ATS Keywords', 'Strengths & Gaps', 'Improvement Tips'].map((f) => (
            <span
              key={f}
              style={{
                fontSize: 11,
                padding: '3px 10px',
                borderRadius: 99,
                border: '1px solid var(--border-hover)',
                color: 'var(--text-muted)',
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {f}
            </span>
          ))}
        </div>
      </div>

      {/* ── Main card ── */}
      <div
        className="card anim-slide-up delay-2"
        style={{ width: '100%', maxWidth: 480, padding: 24 }}
      >
        {/* Tab switcher */}
        <div className="tab-group" style={{ marginBottom: 20 }}>
          <button
            className={`tab-btn ${tab === 'upload' ? 'active' : ''}`}
            onClick={() => { setTab('upload'); setApiError(''); }}
          >
            📎 Upload File
          </button>
          <button
            className={`tab-btn ${tab === 'paste' ? 'active' : ''}`}
            onClick={() => { setTab('paste'); setApiError(''); }}
          >
            📝 Paste Text
          </button>
        </div>

        {/* Tab content */}
        {tab === 'upload' ? (
          <DropZone
            uploadedFile={uploadedFile}
            isReading={isReading}
            error={fileError}
            onFile={handleFile}
            onClear={clearFile}
          />
        ) : (
          <div>
            <textarea
              value={pastedText}
              onChange={(e) => setPasted(e.target.value)}
              placeholder="Paste your full resume text here…"
              style={{ minHeight: 200 }}
              spellCheck={false}
            />
            <p style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
              {pastedText.trim().split(/\s+/).filter(Boolean).length} words
            </p>
          </div>
        )}

        {/* API error */}
        {apiError && (
          <div
            style={{
              marginTop: 12,
              padding: '10px 14px',
              background: 'rgba(239,68,68,0.08)',
              border: '1px solid rgba(239,68,68,0.25)',
              borderRadius: 8,
              fontSize: 13,
              color: '#f87171',
            }}
          >
            ⚠ {apiError}
          </div>
        )}

        {/* Analyse button */}
        <button
          className="btn-primary"
          style={{ marginTop: 16 }}
          disabled={isAnalyzing || !canAnalyze}
          onClick={handleAnalyze}
        >
          {isAnalyzing ? (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <span
                style={{
                  width: 14,
                  height: 14,
                  border: '2px solid rgba(26,8,0,0.3)',
                  borderTopColor: '#1a0800',
                  borderRadius: '50%',
                  animation: 'spin 0.7s linear infinite',
                  display: 'inline-block',
                }}
              />
              Analyzing…
            </span>
          ) : (
            'Analyze Resume →'
          )}
        </button>

        {/* Sample resumes */}
        <div style={{ marginTop: 16, textAlign: 'center' }}>
          <button
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-muted)',
              fontSize: 12,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
            }}
            onClick={() => setShowSamples(!showSamples)}
          >
            Try a sample resume <ChevronDown size={12} style={{ transform: showSamples ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>

          {showSamples && (
            <div
              style={{
                marginTop: 10,
                display: 'flex',
                flexDirection: 'column',
                gap: 6,
              }}
            >
              {(Object.keys(SAMPLE_RESUMES) as SampleResumeKey[]).map((key) => (
                <button
                  key={key}
                  className="btn-ghost"
                  style={{ fontSize: 12, textAlign: 'left' }}
                  onClick={() => loadSample(key)}
                >
                  {SAMPLE_RESUMES[key].label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Footer note */}
      <p
        className="anim-slide-up delay-4"
        style={{ marginTop: 24, fontSize: 11, color: 'var(--text-dim)', textAlign: 'center' }}
      >
        Powered by Claude claude-sonnet-4-20250514 · Your data is never stored
      </p>
    </div>
  );
};
