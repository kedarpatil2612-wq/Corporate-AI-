// ── HistoryPanel ──────────────────────────────────────────────────────────────
// Slide-in panel showing the session's past analyses.
// Clicking an entry reloads that result in ResultsView.

import React from 'react';
import { X, Clock, Trash2 } from 'lucide-react';
import type { HistoryEntry } from '@/hooks/useHistory';
import { scoreColor } from '@/utils/ui';
import type { AnalysisResult } from '@/types';

interface HistoryPanelProps {
  open: boolean;
  onClose: () => void;
  history: HistoryEntry[];
  onLoad: (result: AnalysisResult) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  open,
  onClose,
  history,
  onLoad,
  onRemove,
  onClear,
}) => {
  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.5)',
          zIndex: 200,
          opacity: open ? 1 : 0,
          pointerEvents: open ? 'auto' : 'none',
          transition: 'opacity 0.25s ease',
        }}
      />

      {/* Drawer */}
      <aside
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: 320,
          background: 'var(--bg-card)',
          borderLeft: '1px solid var(--border)',
          zIndex: 300,
          display: 'flex',
          flexDirection: 'column',
          transform: open ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.3s cubic-bezier(0.22,1,0.36,1)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '16px 18px',
            borderBottom: '1px solid var(--border)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Clock size={15} color="var(--text-muted)" />
            <span
              style={{
                fontFamily: "'Syne', sans-serif",
                fontSize: 14,
                fontWeight: 600,
                color: 'var(--text)',
              }}
            >
              History
            </span>
            <span
              style={{
                background: 'var(--bg-muted)',
                color: 'var(--text-muted)',
                fontSize: 11,
                padding: '1px 7px',
                borderRadius: 99,
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {history.length}
            </span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {history.length > 0 && (
              <button
                onClick={onClear}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-dim)',
                  cursor: 'pointer',
                  padding: 4,
                  display: 'flex',
                }}
                title="Clear history"
              >
                <Trash2 size={14} />
              </button>
            )}
            <button
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                padding: 4,
                display: 'flex',
              }}
              aria-label="Close"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* List */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px' }}>
          {history.length === 0 ? (
            <div
              style={{
                textAlign: 'center',
                padding: '48px 16px',
                color: 'var(--text-dim)',
                fontSize: 13,
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 10 }}>📂</div>
              No analyses yet.
              <br />
              Analyze a resume to see it here.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {history.map((entry) => (
                <div
                  key={entry.id}
                  onClick={() => { onLoad(entry.result); onClose(); }}
                  style={{
                    background: 'var(--bg-muted)',
                    border: '1px solid var(--border)',
                    borderRadius: 10,
                    padding: '12px 14px',
                    cursor: 'pointer',
                    transition: 'border-color 0.15s',
                    position: 'relative',
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--border-hover)';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--border)';
                  }}
                >
                  {/* Delete btn */}
                  <button
                    onClick={(e) => { e.stopPropagation(); onRemove(entry.id); }}
                    style={{
                      position: 'absolute',
                      top: 8,
                      right: 8,
                      background: 'none',
                      border: 'none',
                      color: 'var(--text-dim)',
                      cursor: 'pointer',
                      padding: 3,
                      display: 'flex',
                      borderRadius: 4,
                    }}
                    aria-label="Remove entry"
                  >
                    <X size={11} />
                  </button>

                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      marginBottom: 6,
                    }}
                  >
                    {/* Score badge */}
                    <span
                      style={{
                        fontSize: 18,
                        fontWeight: 700,
                        color: scoreColor(entry.score),
                        fontFamily: "'Syne', sans-serif",
                        lineHeight: 1,
                      }}
                    >
                      {entry.score}
                    </span>
                    <span
                      style={{
                        fontSize: 11,
                        color: scoreColor(entry.score),
                        background: `${scoreColor(entry.score)}18`,
                        padding: '1px 7px',
                        borderRadius: 99,
                        fontFamily: "'Syne', sans-serif",
                        fontWeight: 600,
                      }}
                    >
                      {entry.grade}
                    </span>
                  </div>

                  <p
                    style={{
                      fontSize: 12,
                      fontWeight: 500,
                      color: 'var(--text)',
                      marginBottom: 3,
                      paddingRight: 16,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {entry.label}
                  </p>
                  <p style={{ fontSize: 11, color: 'var(--text-dim)' }}>
                    {entry.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                    {' · '}
                    {entry.timestamp.toLocaleDateString([], {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
