// ── Navbar ────────────────────────────────────────────────────────────────────
// Minimal top navigation bar with history toggle button.

import React from 'react';
import { Sparkles, Clock } from 'lucide-react';

interface NavbarProps {
  historyCount: number;
  onHistoryOpen: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ historyCount, onHistoryOpen }) => (
  <nav
    style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      height: 56,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      background: 'rgba(9,9,16,0.85)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--border)',
    }}
  >
    {/* Logo */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div
        style={{
          width: 30,
          height: 30,
          background: 'var(--brand)',
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Sparkles size={15} color="#1a0800" />
      </div>
      <span
        style={{
          fontFamily: "'Syne', sans-serif",
          fontSize: 16,
          fontWeight: 700,
          color: 'var(--text)',
          letterSpacing: '-0.01em',
        }}
      >
        HireSense <span style={{ color: 'var(--brand)' }}>AI</span>
      </span>
    </div>

    {/* Right side */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      {/* Model badge */}
      <span
        style={{
          fontSize: 11,
          color: 'var(--text-dim)',
          fontFamily: "'JetBrains Mono', monospace",
          display: 'flex',
          alignItems: 'center',
          gap: 4,
        }}
      >
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: '50%',
            background: 'var(--success)',
            display: 'inline-block',
            animation: 'pulse-glow 2.5s ease-in-out infinite',
          }}
        />
        claude-sonnet-4-20250514
      </span>

      {/* History button */}
      <button
        onClick={onHistoryOpen}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '5px 12px',
          borderRadius: 8,
          border: '1px solid var(--border-hover)',
          background: 'transparent',
          color: 'var(--text-muted)',
          fontSize: 12,
          cursor: 'pointer',
          fontFamily: "'DM Sans', sans-serif",
          transition: 'all 0.15s',
          position: 'relative',
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLButtonElement).style.background = 'var(--bg-muted)';
          (e.currentTarget as HTMLButtonElement).style.color = 'var(--text)';
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
          (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-muted)';
        }}
        aria-label="View history"
      >
        <Clock size={13} />
        History
        {historyCount > 0 && (
          <span
            style={{
              background: 'var(--brand)',
              color: '#1a0800',
              fontSize: 10,
              fontWeight: 700,
              width: 16,
              height: 16,
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: "'JetBrains Mono', monospace",
            }}
          >
            {historyCount > 9 ? '9+' : historyCount}
          </span>
        )}
      </button>
    </div>
  </nav>
);
