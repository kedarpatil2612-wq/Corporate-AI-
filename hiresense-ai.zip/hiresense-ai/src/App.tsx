// ── App.tsx ───────────────────────────────────────────────────────────────────
// Root component. Manages top-level view state and session history.
//
// View flow:  upload  →  analyzing  →  results
//             ↑_____________________________|  (New Analysis)

import React, { useState } from 'react';
import { Navbar }        from '@/components/layout/Navbar';
import { HistoryPanel }  from '@/components/layout/HistoryPanel';
import { UploadView }    from '@/components/analyzer/UploadView';
import { AnalyzingView } from '@/components/analyzer/AnalyzingView';
import { ResultsView }   from '@/components/analyzer/ResultsView';
import { useHistory }    from '@/hooks/useHistory';
import type { AnalysisResult, AppView } from '@/types';

const App: React.FC = () => {
  const [view, setView]               = useState<AppView>('upload');
  const [result, setResult]           = useState<AnalysisResult | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [currentLabel, setCurrentLabel] = useState('');

  const { history, addEntry, removeEntry, clearHistory } = useHistory();

  const handleAnalyzing = (label: string) => {
    setCurrentLabel(label);
    setView('analyzing');
  };

  const handleResult = (r: AnalysisResult) => {
    setResult(r);
    addEntry(currentLabel || 'Resume', r);
    setTimeout(() => setView('results'), 400);
  };

  const handleLoadHistory = (r: AnalysisResult) => {
    setResult(r);
    setView('results');
  };

  const handleReset = () => {
    setResult(null);
    setView('upload');
  };

  return (
    <>
      <div aria-hidden style={{ position:'fixed', inset:0,
        backgroundImage:'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.025) 1px, transparent 0)',
        backgroundSize:'28px 28px', pointerEvents:'none', zIndex:0 }} />
      <div aria-hidden style={{ position:'fixed', top:'-10%', left:'50%',
        transform:'translateX(-50%)', width:'70vw', height:'50vh',
        background:'radial-gradient(ellipse, rgba(245,158,11,0.05) 0%, transparent 65%)',
        pointerEvents:'none', zIndex:0 }} />

      <Navbar historyCount={history.length} onHistoryOpen={() => setHistoryOpen(true)} />

      <HistoryPanel open={historyOpen} onClose={() => setHistoryOpen(false)}
        history={history} onLoad={handleLoadHistory}
        onRemove={removeEntry} onClear={clearHistory} />

      <main style={{ position:'relative', zIndex:1, paddingTop:56 }}>
        {view === 'upload'    && <UploadView onAnalyzing={handleAnalyzing} onResult={handleResult} />}
        {view === 'analyzing' && <AnalyzingView />}
        {view === 'results'   && result && <ResultsView result={result} onReset={handleReset} />}
      </main>
    </>
  );
};

export default App;
