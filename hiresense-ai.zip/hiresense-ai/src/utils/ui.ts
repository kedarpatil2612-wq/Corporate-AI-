// ── UI utilities ──────────────────────────────────────────────────────────────
import { clsx, type ClassValue } from 'clsx';

/** Merge class names (Tailwind-safe) */
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

/** Return a CSS custom-property colour based on score 0–100 */
export function scoreColor(score: number): string {
  if (score >= 80) return 'var(--success)';
  if (score >= 60) return 'var(--warning)';
  if (score >= 40) return 'var(--danger)';   // reusing danger orange-ish
  return 'var(--danger)';
}

/** Return a Tailwind text-color class based on score */
export function scoreColorClass(score: number): string {
  if (score >= 80) return 'score-excellent';
  if (score >= 60) return 'score-good';
  if (score >= 40) return 'score-fair';
  return 'score-poor';
}

/** Format file size for display */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024)        return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
