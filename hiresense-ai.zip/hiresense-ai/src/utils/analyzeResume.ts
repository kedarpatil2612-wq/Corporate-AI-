// ── Resume analysis engine ────────────────────────────────────────────────────
// Sends the resume to Claude claude-sonnet-4-20250514 via the Anthropic API.
// Falls back to a local rule-based scorer when the API is unavailable.

import type { AnalysisResult, UploadedFile } from '@/types';

// ── Prompt template ──────────────────────────────────────────────────────────
const buildPrompt = (resumeText?: string) => `
You are a senior talent acquisition specialist and career coach.
Analyze the resume ${resumeText ? 'below' : 'attached as a PDF'} and return ONLY a
valid JSON object — no markdown fences, no explanation, no preamble.

Return exactly this shape:
{
  "score": <integer 0-100>,
  "grade": <"A+" | "A" | "B+" | "B" | "C+" | "C" | "D" | "F">,
  "summary": "<2-sentence overall assessment: first sentence strength, second sentence growth area>",
  "sections": {
    "skills":      <0-100>,
    "experience":  <0-100>,
    "education":   <0-100>,
    "formatting":  <0-100>,
    "impact":      <0-100>
  },
  "strengths":         ["<specific strength 1>", "<specific strength 2>", "<specific strength 3>"],
  "weaknesses":        ["<specific weakness 1>", "<specific weakness 2>", "<specific weakness 3>"],
  "suggestions":       ["<actionable tip 1>", "<actionable tip 2>", "<actionable tip 3>", "<actionable tip 4>"],
  "keywords_found":    ["<kw1>", "<kw2>", "<kw3>", "<kw4>", "<kw5>"],
  "keywords_missing":  ["<kw1>", "<kw2>", "<kw3>"]
}

Scoring rubric:
• 85–100: Exceptional — quantified achievements, strong narrative, ATS-optimised
• 70–84:  Good — solid experience, minor gaps, a few improvements needed
• 55–69:  Average — missing metrics, generic language, structural issues
• 40–54:  Below average — sparse content, poor formatting, missing sections
• 0–39:   Needs major work — critical sections absent or very thin content

Be specific and actionable in all fields; avoid generic advice.
${resumeText ? '\nResume:\n' + resumeText : ''}`.trim();

// ── API call ─────────────────────────────────────────────────────────────────
export async function analyzeResume(file: UploadedFile | null, pastedText: string): Promise<AnalysisResult> {
  let messageContent: object[];

  if (file) {
    if (file.encoding === 'base64-pdf') {
      // Send PDF directly — Claude can read it natively
      messageContent = [
        {
          type: 'document',
          source: { type: 'base64', media_type: 'application/pdf', data: file.content },
        },
        { type: 'text', text: buildPrompt() },
      ];
    } else {
      messageContent = [{ type: 'text', text: buildPrompt(file.content) }];
    }
  } else {
    messageContent = [{ type: 'text', text: buildPrompt(pastedText) }];
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1200,
      messages: [{ role: 'user', content: messageContent }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error((err as { error?: { message?: string } }).error?.message ?? `API error ${response.status}`);
  }

  const data = await response.json() as { content?: Array<{ type: string; text?: string }> };
  const raw = data.content?.find((b) => b.type === 'text')?.text ?? '';

  // Strip any accidental markdown fences
  const clean = raw.replace(/```(?:json)?\n?/g, '').replace(/\n?```/g, '').trim();

  try {
    return JSON.parse(clean) as AnalysisResult;
  } catch {
    throw new Error('Could not parse AI response. Please try again.');
  }
}

// ── Rule-based fallback scorer ────────────────────────────────────────────────
// Used for offline demos or when the API key is not set.
export function ruleBasedAnalysis(text: string): AnalysisResult {
  const t = text.toLowerCase();

  // Section detection
  const hasSummary    = /summary|objective|profile/i.test(t);
  const hasExperience = /experience|work history|employment/i.test(t);
  const hasEducation  = /education|degree|university|college|bachelor|master/i.test(t);
  const hasSkills     = /skills|technologies|proficiencies/i.test(t);
  const hasProjects   = /projects|portfolio|github/i.test(t);
  const hasCerts      = /certif|license|credential/i.test(t);

  // Keyword counts
  const techKeywords = ['javascript','typescript','python','react','node','sql','aws','docker','kubernetes','git','api','java','go','rust','c++','css','html'];
  const foundKeywords = techKeywords.filter(k => t.includes(k));

  const hasMetrics    = /\d+%|\d+x|\d+k|\$\d+|million|thousand|\d+ users|\d+ clients/i.test(t);
  const yearCount     = (t.match(/20\d{2}/g) ?? []).length;
  const wordCount     = text.split(/\s+/).length;

  // ── Scoring ────────────────────────────────────────────────────────────────
  let skillsScore      = 30 + Math.min(foundKeywords.length * 7, 50) + (hasCerts ? 10 : 0);
  let experienceScore  = (hasExperience ? 40 : 10) + Math.min(yearCount * 4, 25) + (hasMetrics ? 20 : 0);
  let educationScore   = hasEducation ? 75 : 20;
  let formattingScore  = (hasSummary ? 20 : 0) + (hasSkills ? 20 : 0) + (hasProjects ? 15 : 0) + (wordCount > 200 ? 20 : 10) + 15;
  let impactScore      = (hasMetrics ? 50 : 15) + (hasProjects ? 20 : 0) + (hasCerts ? 15 : 0);

  // Clamp all section scores to 0–100
  const clamp = (n: number) => Math.min(100, Math.max(0, Math.round(n)));
  skillsScore     = clamp(skillsScore);
  experienceScore = clamp(experienceScore);
  educationScore  = clamp(educationScore);
  formattingScore = clamp(formattingScore);
  impactScore     = clamp(impactScore);

  const score = clamp(
    skillsScore * 0.25 +
    experienceScore * 0.30 +
    educationScore * 0.15 +
    formattingScore * 0.15 +
    impactScore * 0.15
  );

  const grade =
    score >= 93 ? 'A+' : score >= 85 ? 'A' : score >= 77 ? 'B+' :
    score >= 70 ? 'B'  : score >= 62 ? 'C+': score >= 55 ? 'C'  :
    score >= 45 ? 'D'  : 'F';

  // ── Feedback ───────────────────────────────────────────────────────────────
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const suggestions: string[] = [];

  if (foundKeywords.length >= 6) strengths.push(`Strong technical keyword presence (${foundKeywords.length} tech keywords detected)`);
  if (hasExperience)             strengths.push('Experience section clearly present');
  if (hasEducation)              strengths.push('Education credentials included');
  if (hasMetrics)                strengths.push('Quantified achievements strengthen impact');
  if (hasProjects)               strengths.push('Projects section demonstrates initiative');
  if (hasCerts)                  strengths.push('Certifications add credibility');
  if (hasSummary)                strengths.push('Professional summary provides context');

  if (!hasMetrics)    weaknesses.push('No quantified achievements found (e.g. "increased sales 30%")');
  if (!hasProjects)   weaknesses.push('No projects or portfolio links detected');
  if (!hasSummary)    weaknesses.push('Missing professional summary / objective section');
  if (foundKeywords.length < 4) weaknesses.push('Limited technical keywords may hurt ATS matching');
  if (!hasCerts)      weaknesses.push('No certifications listed');
  if (wordCount < 150) weaknesses.push('Resume appears too brief — add more detail');

  if (!hasMetrics)
    suggestions.push('Add measurable outcomes to each bullet (%, $, numbers of users/clients)');
  if (foundKeywords.length < 5)
    suggestions.push('Include more relevant tech keywords to pass Applicant Tracking Systems');
  if (!hasSummary)
    suggestions.push('Add a 2–3 sentence professional summary at the top');
  if (!hasProjects)
    suggestions.push('Add a Projects section with GitHub links or live demos');
  suggestions.push('Tailor your resume to each job description by mirroring key phrases');

  const missingKeywords = ['CI/CD', 'Agile', 'REST API', 'microservices', 'system design']
    .filter(k => !t.includes(k.toLowerCase()));

  return {
    score,
    grade,
    summary: `This resume scores ${score}/100 based on rule-based analysis. ${
      score >= 70
        ? 'The core sections are solid; adding quantified achievements would push it higher.'
        : 'Several key sections are missing or underdeveloped — see suggestions below.'
    }`,
    sections: {
      skills: skillsScore,
      experience: experienceScore,
      education: educationScore,
      formatting: formattingScore,
      impact: impactScore,
    },
    strengths: strengths.slice(0, 4),
    weaknesses: weaknesses.slice(0, 4),
    suggestions: suggestions.slice(0, 5),
    keywords_found: foundKeywords.slice(0, 6),
    keywords_missing: missingKeywords.slice(0, 4),
  };
}
