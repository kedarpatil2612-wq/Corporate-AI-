// ── Sample resumes for testing ─────────────────────────────────────────────────

export const SAMPLE_RESUMES = {
  senior_engineer: {
    label: 'Senior Engineer (Strong)',
    text: `John Smith — Senior Software Engineer
john.smith@email.com | (555) 123-4567 | github.com/johnsmith | linkedin.com/in/johnsmith

SUMMARY
Experienced full-stack engineer with 5+ years building scalable distributed systems. Led
teams of 4–8 at growth-stage startups; delivered features used by 2M+ users. Passionate
about clean architecture, developer experience, and measurable impact.

EXPERIENCE

Senior Software Engineer | TechCorp Inc. | Jan 2021 – Present
• Led microservices migration (Node.js → Go), cutting p99 latency 40% across 2M+ users
• Designed real-time event pipeline (Kafka + Redis Streams) handling 500K events/day
• Mentored 4 junior engineers; established PR review standards reducing bugs 30%
• Championed observability (OpenTelemetry, Grafana), cutting MTTR from 45 min → 8 min
Tech: React 18, TypeScript, Go, Node.js, AWS (ECS, RDS, S3), PostgreSQL, Redis, Kafka

Software Engineer | StartupXYZ | Mar 2019 – Dec 2020
• Delivered 3 major product features end-to-end; increased DAU 22% in Q3 2020
• Built analytics dashboard used daily by 50+ enterprise clients
• Reduced CI build time 55% by parallelising test suites in GitHub Actions
Tech: Vue.js, Python 3, Django, Docker, MySQL, Elasticsearch

Junior Developer | WebAgency | Jun 2018 – Feb 2019
• Developed 12 client websites and 2 internal web apps
Tech: HTML5, CSS3, JavaScript ES6, WordPress, PHP

EDUCATION
Bachelor of Science, Computer Science — State University, 2014–2018 | GPA 3.7 / 4.0
Dean's List 6 semesters | Senior thesis: "Optimising graph traversal at scale" (A+)

SKILLS
Languages: JavaScript/TypeScript, Go, Python, Java, SQL
Frontend: React, Vue.js, Next.js, Tailwind CSS, Storybook
Backend: Node.js, Express, Fastify, Django, FastAPI, GraphQL
Cloud & DevOps: AWS (SA-certified), Docker, Kubernetes, Terraform, GitHub Actions
Databases: PostgreSQL, MySQL, MongoDB, Redis, DynamoDB

PROJECTS
Personal finance SaaS (2023–): 400+ paying users, $1.2K MRR
Open-source CLI tool (Go): 1.4K GitHub ⭐, 9K downloads, 18 contributors

CERTIFICATIONS
AWS Certified Solutions Architect – Associate (2022)
Google Cloud Professional Cloud Developer (2023)`,
  },

  fresh_graduate: {
    label: 'Fresh Graduate (Needs Work)',
    text: `Sarah Johnson
sarah.johnson@gmail.com | 555-987-6543

OBJECTIVE
Looking for a job in software development where I can use my skills.

EDUCATION
Computer Science degree at City College 2020-2024

SKILLS
• Java
• Python
• HTML
• CSS
• Some JavaScript
• Microsoft Office

PROJECTS
Todo App: Made a todo app for my class project.
Website: Built a personal website.

EXPERIENCE
Internship at Local Company (Summer 2023)
Helped with some tasks and learned new things.

HOBBIES
Gaming, Reading, Cooking`,
  },

  marketing_manager: {
    label: 'Marketing Manager (Mid-level)',
    text: `Priya Patel
priya.patel@email.com | LinkedIn: linkedin.com/in/priya-patel-mktg

PROFESSIONAL SUMMARY
Results-driven marketing manager with 4 years of experience in digital marketing, brand
strategy, and performance analytics. Proven ability to grow online presence and drive ROI.

EXPERIENCE

Marketing Manager | GrowthBrand Co. | 2022 – Present
• Managed $500K annual digital advertising budget across Google, Meta, and LinkedIn
• Increased organic search traffic 78% YoY through SEO content strategy
• Led rebrand project that improved NPS score from 32 to 61 in 6 months
• Built and managed a team of 3 content creators and 1 designer

Digital Marketing Specialist | AgencyX | 2020 – 2022
• Executed email campaigns averaging 34% open rate (industry avg 21%)
• A/B tested landing pages improving conversion rate from 2.1% to 4.8%
• Managed social media accounts growing followers from 8K to 45K in 18 months

Marketing Intern | StartupABC | Summer 2019
• Assisted with social media content creation and scheduling
• Compiled weekly analytics reports for senior team

EDUCATION
B.B.A. Marketing — Business University, 2020 | GPA 3.5

SKILLS
Digital Marketing: SEO/SEM, Google Ads, Meta Ads, Email Marketing (HubSpot, Mailchimp)
Analytics: Google Analytics 4, Looker Studio, Tableau, Excel
Content: Copywriting, Content Strategy, Figma (basic), Canva
CRM: Salesforce, HubSpot, Klaviyo

CERTIFICATIONS
Google Analytics 4 Certified (2023) | HubSpot Content Marketing (2022)`,
  },
} as const;

export type SampleResumeKey = keyof typeof SAMPLE_RESUMES;
