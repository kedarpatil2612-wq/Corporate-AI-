// ── Resume analysis result shape ──────────────────────────────────────────────

export interface SectionScores {
  skills: number;
  experience: number;
  education: number;
  formatting: number;
  impact: number;
}

export interface AnalysisResult {
  /** Overall score 0–100 */
  score: number;
  /** Letter grade: A+ | A | B+ | B | C+ | C | D | F */
  grade: string;
  /** Two-sentence overall summary */
  summary: string;
  /** Per-section breakdown scores */
  sections: SectionScores;
  /** What the resume does well */
  strengths: string[];
  /** Areas needing improvement */
  weaknesses: string[];
  /** Actionable improvement tips */
  suggestions: string[];
  /** Strong ATS keywords already present */
  keywords_found: string[];
  /** Keywords worth adding for ATS */
  keywords_missing: string[];
}

export type AppView = 'upload' | 'analyzing' | 'results';

export type InputTab = 'upload' | 'paste';

export interface UploadedFile {
  name: string;
  size: number;
  type: string;
  /** base64 string for PDFs, plain text for TXT */
  content: string;
  /** How the content field is encoded */
  encoding: 'base64-pdf' | 'text';
}
