// ── useFileReader hook ────────────────────────────────────────────────────────
// Reads a File object into an UploadedFile shape.
// PDFs → base64; TXT → plain text string.

import { useState, useCallback } from 'react';
import type { UploadedFile } from '@/types';

const ALLOWED_TYPES = ['application/pdf', 'text/plain'];
const ALLOWED_EXTS  = ['pdf', 'txt'];
const MAX_SIZE_MB    = 5;

interface UseFileReaderResult {
  uploadedFile: UploadedFile | null;
  error: string;
  isReading: boolean;
  handleFile: (file: File | null) => void;
  clearFile: () => void;
}

export function useFileReader(): UseFileReaderResult {
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [error, setError] = useState('');
  const [isReading, setIsReading] = useState(false);

  const handleFile = useCallback((file: File | null) => {
    setError('');
    setUploadedFile(null);

    if (!file) return;

    // Validate type
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    if (!ALLOWED_TYPES.includes(file.type) && !ALLOWED_EXTS.includes(ext)) {
      setError('Unsupported file type. Please upload a PDF or plain-text (.txt) file.');
      return;
    }

    // Validate size
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File is too large. Maximum size is ${MAX_SIZE_MB} MB.`);
      return;
    }

    setIsReading(true);

    const reader = new FileReader();

    if (file.type === 'application/pdf' || ext === 'pdf') {
      // Read as Data URL, then strip the prefix to get base64
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        const base64  = dataUrl.split(',')[1];
        setUploadedFile({
          name: file.name,
          size: file.size,
          type: file.type || 'application/pdf',
          content: base64,
          encoding: 'base64-pdf',
        });
        setIsReading(false);
      };
      reader.onerror = () => {
        setError('Failed to read the file. Please try again.');
        setIsReading(false);
      };
      reader.readAsDataURL(file);
    } else {
      // Plain text
      reader.onload = (e) => {
        setUploadedFile({
          name: file.name,
          size: file.size,
          type: file.type || 'text/plain',
          content: e.target?.result as string,
          encoding: 'text',
        });
        setIsReading(false);
      };
      reader.onerror = () => {
        setError('Failed to read the file. Please try again.');
        setIsReading(false);
      };
      reader.readAsText(file);
    }
  }, []);

  const clearFile = useCallback(() => {
    setUploadedFile(null);
    setError('');
  }, []);

  return { uploadedFile, error, isReading, handleFile, clearFile };
}
