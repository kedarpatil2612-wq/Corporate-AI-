// ── useHistory ────────────────────────────────────────────────────────────────
// Keeps a lightweight in-memory log of past analyses (session only).
// Each entry is stamped with the filename/label and timestamp.

import { useState, useCallback } from 'react';
import type { AnalysisResult } from '@/types';

export interface HistoryEntry {
  id: string;
  label: string;
  score: number;
  grade: string;
  timestamp: Date;
  result: AnalysisResult;
}

interface UseHistoryResult {
  history: HistoryEntry[];
  addEntry: (label: string, result: AnalysisResult) => void;
  removeEntry: (id: string) => void;
  clearHistory: () => void;
}

export function useHistory(): UseHistoryResult {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const addEntry = useCallback((label: string, result: AnalysisResult) => {
    const entry: HistoryEntry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      label,
      score: result.score,
      grade: result.grade,
      timestamp: new Date(),
      result,
    };
    setHistory((prev) => [entry, ...prev].slice(0, 20)); // keep latest 20
  }, []);

  const removeEntry = useCallback((id: string) => {
    setHistory((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const clearHistory = useCallback(() => setHistory([]), []);

  return { history, addEntry, removeEntry, clearHistory };
}
