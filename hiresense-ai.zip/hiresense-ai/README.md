# HireSense AI 🧠

An AI-powered resume analyzer built with **React + Vite + TypeScript + Tailwind CSS**, powered by **Claude claude-sonnet-4-20250514**.

Upload or paste a resume and instantly receive:
- **Resume Score** (0–100) with letter grade
- **Section Breakdown** — Skills, Experience, Education, Formatting, Impact
- **Strengths** & **Weaknesses** (specific, not generic)
- **Improvement Suggestions** (numbered, actionable)
- **ATS Keyword Analysis** — found vs. missing keywords

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

> **Note:** The app calls the Anthropic API automatically from the browser. When running inside Claude artifacts, the API key is pre-injected. For standalone use, see **API Key Setup** below.

---

## 🔑 API Key Setup (standalone)

The Anthropic API key must be available to the frontend.

**Option A — environment variable (Vite)**

Create a `.env.local` file in the project root:

```env
VITE_ANTHROPIC_API_KEY=sk-ant-xxxxx
```

Then update `src/utils/analyzeResume.ts` — add the header:

```ts
headers: {
  'Content-Type': 'application/json',
  'x-api-key': import.meta.env.VITE_ANTHROPIC_API_KEY,
  'anthropic-version': '2023-06-01',
},
```

**Option B — proxy backend**

See the `backend-example/` folder (not included) for an Express proxy that forwards requests without exposing the key to the browser.

---

## 📁 Project Structure

```
hiresense-ai/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── analyzer/
│   │   │   ├── UploadView.tsx      # Upload / paste tab, sample picker
│   │   │   ├── AnalyzingView.tsx   # Animated loading screen
│   │   │   └── ResultsView.tsx     # Full results dashboard
│   │   ├── layout/
│   │   │   └── Navbar.tsx
│   │   └── ui/
│   │       ├── DropZone.tsx        # Drag-and-drop file upload
│   │       ├── ScoreRing.tsx       # Animated SVG score ring
│   │       └── SectionBar.tsx      # Animated score bars
│   ├── hooks/
│   │   └── useFileReader.ts        # File reading hook (PDF + TXT)
│   ├── types/
│   │   └── index.ts                # TypeScript type definitions
│   ├── utils/
│   │   ├── analyzeResume.ts        # API call + rule-based fallback
│   │   ├── sampleResumes.ts        # 3 built-in sample resumes
│   │   └── ui.ts                   # cn(), scoreColor(), formatFileSize()
│   ├── App.tsx                     # Root component + view state
│   ├── main.tsx
│   └── index.css                   # Design tokens + global styles
├── index.html
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

---

## 🧠 How Scoring Works

**AI Mode (Anthropic API)**
The full resume text (or base64-encoded PDF) is sent to Claude claude-sonnet-4-20250514 with a
structured prompt requesting a JSON response with score, grade, section breakdown,
strengths, weaknesses, suggestions, and ATS keywords.

**Rule-Based Fallback**
If the API is unreachable, a local scoring algorithm activates:

| Criterion | Weight | Logic |
|---|---|---|
| Skills | 25% | Tech keyword count × 7 pts, certs +10 |
| Experience | 30% | Section presence, year count, metrics |
| Education | 15% | Degree detection |
| Formatting | 15% | Summary, skills, projects, word count |
| Impact | 15% | Quantified metrics, projects, certs |

---

## 📦 Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18 + TypeScript |
| Bundler | Vite 5 |
| Styling | Tailwind CSS 3 + CSS custom properties |
| AI | Anthropic claude-sonnet-4-20250514 |
| Icons | Lucide React |
| File parsing | FileReader API (PDF → base64, TXT → string) |

---

## 🛠 Build for Production

```bash
npm run build
npm run preview
```

---

## 📄 Licence

MIT — free for personal, educational, and commercial use.
