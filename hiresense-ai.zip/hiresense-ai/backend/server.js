// ── backend/server.js ─────────────────────────────────────────────────────────
// Optional Express proxy server that keeps your Anthropic API key server-side.
//
// Usage:
//   cd backend
//   npm install
//   ANTHROPIC_API_KEY=sk-ant-xxxx node server.js
//
// Then point the frontend at http://localhost:3001/api/analyze
// by changing the fetch URL in src/utils/analyzeResume.ts.

import express from 'express';
import cors    from 'cors';
import fetch   from 'node-fetch';

const app  = express();
const PORT = process.env.PORT ?? 3001;

// Allow requests from the Vite dev server
app.use(cors({ origin: ['http://localhost:5173', 'http://localhost:4173'] }));
app.use(express.json({ limit: '10mb' })); // allow large base64 PDFs

// ── Health check ────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// ── Proxy endpoint ───────────────────────────────────────────────────────────
// Accepts the same request body as the Anthropic /v1/messages endpoint and
// forwards it with the server-side API key.
app.post('/api/analyze', async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY is not set on the server.' });
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(req.body),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      return res.status(upstream.status).json(data);
    }

    return res.json(data);
  } catch (err) {
    console.error('Proxy error:', err);
    return res.status(502).json({ error: 'Failed to reach Anthropic API.' });
  }
});

app.listen(PORT, () => {
  console.log(`✅  HireSense AI proxy running at http://localhost:${PORT}`);
});
