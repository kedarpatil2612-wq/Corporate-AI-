/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Syne', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        brand: {
          50: '#fffbeb',
          100: '#fef3c7',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          900: '#451a03',
        },
        surface: {
          DEFAULT: '#0d0d14',
          card: '#13131f',
          border: '#1e1e30',
          muted: '#1a1a28',
        }
      },
      animation: {
        'spin-slow': 'spin 2s linear infinite',
        'pulse-slow': 'pulse 2.5s ease-in-out infinite',
        'slide-up': 'slideUp 0.4s ease both',
        'ring-fill': 'ringFill 1.5s cubic-bezier(0.4,0,0.2,1) both',
        'bar-grow': 'barGrow 1s cubic-bezier(0.4,0,0.2,1) both',
      },
      keyframes: {
        slideUp: { from: { opacity: 0, transform: 'translateY(16px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        ringFill: { from: { strokeDashoffset: '402' }, to: { strokeDashoffset: 'var(--offset)' } },
        barGrow: { from: { width: '0%' }, to: { width: 'var(--width)' } },
      }
    }
  },
  plugins: [],
}
